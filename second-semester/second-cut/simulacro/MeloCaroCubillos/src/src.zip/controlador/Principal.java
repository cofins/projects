package controlador;

public class Principal {
  public static void main(String[] args) {
    PicaFijaControlador pc = new PicaFijaControlador();
  }
}
